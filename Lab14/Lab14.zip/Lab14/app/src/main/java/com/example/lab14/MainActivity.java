package com.example.lab14;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity{

    MediaPlayer mediaPlayer;
    AudioManager audioManager;
    TextView position, time, now, m1,m2;
    SeekBar seekBar, volume;
    ImageView play, pause, stop,rew, ff;

    int pausePosition;
    Handler handler = new Handler();
    Runnable runnable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play = (ImageView) findViewById(R.id.play);
        pause =(ImageView) findViewById(R.id.pause);
        stop = (ImageView) findViewById(R.id.stop);
        rew = (ImageView)findViewById(R.id.rew);
        ff = (ImageView)findViewById(R.id.ff);
        position = (TextView)findViewById(R.id.position);
        time = (TextView)findViewById(R.id.duration);
        now = (TextView)findViewById(R.id.now);
        volume = (SeekBar)findViewById(R.id.volume);
        seekBar = (SeekBar)findViewById(R.id.seekBar);

        audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        int maxVol =  audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,progress,0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer==null){
                    mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.ragtime_proud_music_preview);
                    mediaPlayer.start();
                    seekBar.setMax(mediaPlayer.getDuration());
                    handler.postDelayed(runnable,0);
                }else if(!mediaPlayer.isPlaying()){
                    mediaPlayer.seekTo(pausePosition);
                    mediaPlayer.start();
                    seekBar.setMax(mediaPlayer.getDuration());
                    handler.postDelayed(runnable,0);
                }
                now.setText(convertFormat(mediaPlayer.getCurrentPosition()));
            }
        });

        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer != null){
                    mediaPlayer.pause();
                    pausePosition = mediaPlayer.getCurrentPosition();
                    handler.removeCallbacks(runnable);
                }
                now.setText(convertFormat(mediaPlayer.getCurrentPosition()));
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer!=null) {
                    mediaPlayer.stop();
                    pausePosition = mediaPlayer.getCurrentPosition();
                    handler.removeCallbacks(runnable);
                    mediaPlayer = null;
                }
                now.setText(convertFormat(mediaPlayer.getCurrentPosition()));
            }
        });

        rew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int current = mediaPlayer.getCurrentPosition();
                if(mediaPlayer.isPlaying() && current > 10000){
                    current = current - 10000;
                    position.setText(convertFormat(current));
                    mediaPlayer.seekTo(current);
                }
                now.setText(convertFormat(mediaPlayer.getCurrentPosition()));
            }
        });

        ff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currnet = mediaPlayer.getCurrentPosition();
                int duration = mediaPlayer.getDuration();
                if(mediaPlayer.isPlaying() && duration != currnet){
                    currnet = currnet + 30000;
                    position.setText((convertFormat(currnet)));
                    mediaPlayer.seekTo(currnet);
                }
                now.setText(convertFormat(mediaPlayer.getCurrentPosition()));
            }
        });

        mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.ragtime_proud_music_preview);
        runnable = new Runnable() {
            @Override
            public void run() {
                seekBar.setProgress(mediaPlayer.getCurrentPosition());
                handler.postDelayed(this,100);
            }
        };

        int duration = mediaPlayer.getDuration();
        String sDuration = convertFormat(duration);
        time.setText(sDuration);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    mediaPlayer.seekTo(progress);
                }
                position.setText(convertFormat(mediaPlayer.getCurrentPosition()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mediaPlayer.seekTo(0);
            }
        });
    }

    @SuppressLint("DefaultLocale")
    private String convertFormat(int duration) {
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) -
                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)));
    }
}