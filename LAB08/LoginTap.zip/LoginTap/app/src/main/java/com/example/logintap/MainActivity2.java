package com.example.logintap;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private ImageButton lButton, sButton, cButton, mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        sButton = (ImageButton)findViewById(R.id.site_button);
        lButton = (ImageButton)findViewById(R.id.locate);
        cButton = (ImageButton)findViewById(R.id.call_button);
        mButton = (ImageButton)findViewById(R.id.mail_button);

        LocationManager location;

        sButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse( "http://newtreat.co.in/");

                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(i);
            }
        });

        lButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=\" + \"12.929951,77.609036"));
                startActivity(i);
            }
        });

        cButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + "9158640715"));
                startActivity(i);
            }
        });

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mailto = "mailto:riya.gurbani@mca.christuniversity.in" +
                        "?cc=" +
                        "&subject=" + Uri.encode("Hello!!!") +
                        "&body=" + Uri.encode("\"Good Morning !, This is a test email sent through the emulator APP\"");
                Intent eI = new Intent(Intent.ACTION_SENDTO);
                eI.setData(Uri.parse(mailto));

                try {
                    startActivity(eI);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getApplicationContext(),"Error opening the mail", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}