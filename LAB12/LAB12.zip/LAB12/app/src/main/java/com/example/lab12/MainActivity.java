package com.example.lab12;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    WifiManager wifiManager;
    TextView wifistatus;
    Switch wifiSwitch;


    @SuppressLint("WifiManagerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        wifistatus = (TextView) findViewById(R.id.wifi_status);
        wifiSwitch = (Switch) findViewById(R.id.wifi_switch);
        if(wifiManager.isWifiEnabled()){
        wifistatus.setText("Wifi is ON");
        wifiSwitch.setChecked(true);

        }
        else
        {
            wifistatus.setText("WIFI is OFF");
            wifiSwitch.setChecked(false);

        }
        wifiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    wifiManager.setWifiEnabled(true);
                    wifistatus.setText("Wifi is ON");
                    Toast.makeText(MainActivity.this, "Wifi may take a moment to connect", Toast.LENGTH_SHORT).show();

                }
                else {
                    wifiManager.setWifiEnabled(false);
                    wifistatus.setText("Wifi is OFF");
                }
            }
        });

    }
}