package com.example.lab16;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    String col_val="";
    TextView textView;
    EditText atr1;
    Button button;
    ProgressBar progressBar, progressIndicator;
    ConstraintLayout cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);
        progressBar = findViewById(R.id.progressBar);
        progressIndicator = findViewById(R.id.progressIndicator);
        atr1 = findViewById(R.id.atr1);
        cl = findViewById(R.id.cl1);
        textView.setText("");
        progressIndicator.setVisibility(View.INVISIBLE);

    }

    public void uploadTask(View view) {
//        Toast.makeText(this, "button clicked...", Toast.LENGTH_SHORT).show();

//        UploadTask uploadTask = new UploadTask();
//        uploadTask.execute();

        new UploadTask().execute("This is the string passaed.");

    }

    class UploadTask extends AsyncTask<String, Integer, String> {

        @Override
        protected void onPreExecute() {
            Log.i(TAG, "onPreExecute: " + Thread.currentThread().getName());

            textView.setText("Applying Chnages...");
            progressIndicator.setVisibility(View.VISIBLE);
            button.setEnabled(false);
        }

        @Override
        protected String doInBackground(String... strings) {

            Log.i(TAG, "doInBackground: string passed:" + strings[0]);
            Log.i(TAG, "doInBackground: Thread: " + Thread.currentThread().getName());
            for (int i=0; i<10; i++) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                publishProgress(i);
            }


            return "Changes Applied";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            progressBar.setProgress(values[0] + 1);
            Log.i(TAG, "onProgressUpdate: " + Thread.currentThread().getName());
        }

        @Override
        protected void onPostExecute(String string) {
            Log.i(TAG, "onPostExecute: " + Thread.currentThread().getName());
            col_val = atr1.getText().toString();
            if(col_val.equalsIgnoreCase("red"))
            {
                cl.setBackgroundColor(Color.RED);
            }
            else if(col_val.equalsIgnoreCase("green"))
            {
                cl.setBackgroundColor(Color.GREEN);
            }
            else {
                cl.setBackgroundColor(Color.rgb(255, 153, 0));
            }
            textView.setText(string);
            progressIndicator.setVisibility(View.INVISIBLE);
            button.setEnabled(true);
        }
    }
}