package com.example.malab9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText texte;
    View main;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texte = findViewById(R.id.text_choice);
        main = findViewById(R.id.layout_main);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        String number = "7821984232";
        switch (id){
            case R.id.send:
                String url = "https://api.whatsapp.com/send?phone="+number;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                Toast.makeText(getApplicationContext(),"Item 1 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.share:
                String txt = texte.getText().toString();
                if(txt.isEmpty()){
                    texte.setError("Enter text to share");
                    return true;
                }
                String mimeType = "text/plain";
                ShareCompat.IntentBuilder
                        .from(this)
                        .setType(mimeType)
                        .setChooserTitle("share_text_with")
                        .setText(txt)
                        .startChooser();
                return true;
            case R.id.color:
                main.setBackgroundColor(Color.parseColor("#808080"));
                return true;
            case R.id.exit:
                finish();
                return true;

            case R.id.phone:
                Uri num = Uri.parse("tel:8302295386");
                Intent callIntent = new Intent(Intent.ACTION_DIAL, num);
                startActivity(callIntent);
                return true;

            case R.id.website:
                Uri webpage = Uri.parse("https://kp.christuniversity.in/KnowledgePro/StudentLogin.do");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            default:
                return super.onOptionsItemSelected(item);
        }
    }




}