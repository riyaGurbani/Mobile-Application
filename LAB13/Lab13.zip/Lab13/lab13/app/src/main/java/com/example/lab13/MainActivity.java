package com.example.lab13;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    View main;
    TabLayout tabLayout;


    ActionBarDrawerToggle toggle;
    NavigationView navigationView;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        getSupportActionBar().setTitle("");

    }
    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.winter:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new winter_season()).addToBackStack(null).commit();
                break;

            case R.id.summer:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new summer_season()).addToBackStack(null).commit();
                break;

            case R.id.rainy:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new rainy_season()).addToBackStack(null).commit();
                break;

            case R.id.nav_exit:
                Toast.makeText(this, "Application Closed", Toast.LENGTH_SHORT).show();
                finish();
                break;

            case R.id.autumn:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new autumn_season()).addToBackStack(null).commit();
                break;

            case R.id.nav_temp:
                Intent intent = new Intent(this, temperature.class);
                startActivity(intent);
                break;

            case R.id.nav_event:
                Intent calendarIntent = new Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI);
                Calendar beginTime = Calendar.getInstance();
                beginTime.set(2021, 0, 23, 7, 30);
                Calendar endTime = Calendar.getInstance();
                endTime.set(2021, 0, 23, 10, 30);
                calendarIntent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginTime.getTimeInMillis());
                calendarIntent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endTime.getTimeInMillis());
                calendarIntent.putExtra(CalendarContract.Events.TITLE, "Mobile Application");
                calendarIntent.putExtra(CalendarContract.Events.EVENT_LOCATION, "GC");
                startActivity(calendarIntent);
                return true;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}