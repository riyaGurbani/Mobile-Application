package com.example.lab13;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


public class summer_season extends Fragment {


    EditText editText;
    Button button;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_summer_season, container, false);

        editText=view.findViewById(R.id.stb1);
    button=view.findViewById(R.id.sbt1);
    button.setOnClickListener(new View.OnClickListener() {
@Override
            public void onClick(View view) {
                String name=editText.getText().toString().trim();
              if(name.equals("")){
                                        Toast.makeText(getActivity(), "Please fill the field", Toast.LENGTH_SHORT).show();
                    	                }else {
                    	                    rainy_season fragment =new rainy_season(name);
                    	                    FragmentManager fragmentManager=getFragmentManager();
                    	                    FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                    	                    fragmentTransaction.replace(R.id.fragment_container,fragment);
                    	                    fragmentTransaction.commit();
                    	                }
                	            }
        });


        return view;
    }
}