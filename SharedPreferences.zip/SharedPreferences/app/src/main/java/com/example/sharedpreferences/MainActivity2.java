package com.example.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    TextView name;
    TextView locker;
    public static final String mypreference = "mypref";
    public static final String Name = "nameKey";
    public static final String Locker = "lockerKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name = (TextView) findViewById(R.id.etName);
        locker = (TextView) findViewById(R.id.locker_pass);
        sharedPreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        if (sharedPreferences.contains(Name)) {
            name.setText(sharedPreferences.getString(Name, ""));
        }
        if (sharedPreferences.contains(Locker)) {
            locker.setText(sharedPreferences.getString(Locker, ""));

        }

    }

    public void Save(View view) {
        String n = name.getText().toString();
        String l = locker.getText().toString();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(Name, n);
        editor.putString(Locker, l);
        editor.commit();
    }

    public void clear(View view) {
        name = (TextView) findViewById(R.id.etName);
        locker = (TextView) findViewById(R.id.locker_pass);
        name.setText("");
        locker.setText("");
    }

    public void Get(View view) {
        name = (TextView) findViewById(R.id.etName);
        locker = (TextView) findViewById(R.id.locker_pass);
        sharedPreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);

        if (sharedPreferences.contains(Name)) {
            name.setText(sharedPreferences.getString(Name, ""));
        }
        if (sharedPreferences.contains(Locker)) {
            locker.setText(sharedPreferences.getString(Locker, ""));

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
}