package com.example.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText mEdit, pEdit;
    private Button loginButton;
    TextView t;
    int count = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mEdit = (EditText)findViewById(R.id.user_input);
        pEdit = (EditText)findViewById(R.id.pass_input);
        loginButton = (Button)findViewById(R.id.button);
        t = (TextView)findViewById(R.id.message);
        t.setVisibility(View.GONE);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mEdit.getText().toString().equals("user") &&
                        pEdit.getText().toString().equals("12345")) {
                    Toast.makeText(getApplicationContext(), "Congrats, you hit the mark", Toast.LENGTH_SHORT).show();
                    openSecondActivity();
                }
                else {
                    Toast.makeText(getApplicationContext(),"Wrong Input Buddy..", Toast.LENGTH_SHORT).show();
                    t.setVisibility(View.VISIBLE);
                    count--;
                    t.setText(Integer.toString(count));

                    if(count == 0){
                        loginButton.setEnabled(false);
                    }
                }
            }
        });

    }

    private void openSecondActivity() {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
}